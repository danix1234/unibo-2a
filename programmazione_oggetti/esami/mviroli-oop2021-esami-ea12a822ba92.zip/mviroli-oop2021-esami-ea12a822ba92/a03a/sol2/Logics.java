package a03a.sol2;

import java.util.Set;

public interface Logics{
	
	void hit(int x, int y);
	
	boolean isSelected(int x, int y);
	
	boolean isOver();
    
}
