package a03b.sol2;

import java.util.Optional;

public interface Logics{
	
	Optional<Pair<Integer,Integer>> next();
}
