package a01c.sol2;

import java.util.Set;

public interface Logics{
	
	boolean hit(int x, int y);
	
	boolean isSelected(int x, int y);
	
}
