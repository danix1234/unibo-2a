package pr2016.a06.sol2;

public interface Model {
    
    void hit(int pos);
    
    boolean isEnabled(int pos);
    
    String text(int pos);
}
