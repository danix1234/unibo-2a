package ex2016.a03a.sol2;


public interface Model {
    
    void moveA();
    
    void moveB();
    
    void reset();
    
    boolean over();
    
    int getAPosition();
    
    int getBPosition();
    
}
