package pr2016.a05.sol2;

public interface Model {
    
    void move();
    
    int getPosition();
    
    void direction(boolean right);
}
