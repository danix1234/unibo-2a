package ex2016.a01b.sol2;

import java.util.Iterator;

public interface Model extends Iterator<Integer>{
    
}
