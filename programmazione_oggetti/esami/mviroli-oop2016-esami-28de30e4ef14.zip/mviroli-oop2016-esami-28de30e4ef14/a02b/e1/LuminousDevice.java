package ex2016.a02b.e1;


/**
 * Simply, a device with also the methods of being Luminuous
 */
public interface LuminousDevice extends Device, Luminous {
    
}
