package ex2016.a03b.sol2;

public interface Model {
    
    void advance();
    
    boolean hit();
    
    int getPosition();
    
}
