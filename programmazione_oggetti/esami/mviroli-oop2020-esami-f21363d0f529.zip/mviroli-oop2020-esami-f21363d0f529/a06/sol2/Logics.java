package a06.sol2;

import java.util.*;

public interface Logics{
	
	List<Integer> getNumbers();
	
	int getItemPosition();
	
	void next();
	
	boolean isOver();
}
