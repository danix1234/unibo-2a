package a03b.sol2;

public interface Logics{
    
    void hit(int row, int col);
    
    boolean getCell(int row, int col);
}
