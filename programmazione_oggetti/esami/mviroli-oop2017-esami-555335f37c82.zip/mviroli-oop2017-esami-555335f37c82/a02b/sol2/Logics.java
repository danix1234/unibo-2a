package a02b.sol2;

import java.util.List;

public interface Logics {
	
	List<String> allLines();
	
	void remove(int index);
	
	void concat(int index);
	
	void add(int index);
}
