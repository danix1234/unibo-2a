package a02b.e2;

import java.io.*;
import java.nio.file.Paths;
import java.awt.*;
import javax.swing.*;

public class GUI {

	public GUI(String fileName) throws IOException {
	}

}
