package a06.sol2;

import java.util.*;

public interface Logics {
	
	int size();
	
	List<String> currentNames();
	
	String hit(int elem);
		
	void reset();
}
