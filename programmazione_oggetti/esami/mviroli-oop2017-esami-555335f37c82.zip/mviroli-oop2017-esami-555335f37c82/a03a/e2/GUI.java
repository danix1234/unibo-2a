package a03a.e2;

import java.io.*;

public class GUI {

	public GUI(String fileName) throws IOException {
	}

}
