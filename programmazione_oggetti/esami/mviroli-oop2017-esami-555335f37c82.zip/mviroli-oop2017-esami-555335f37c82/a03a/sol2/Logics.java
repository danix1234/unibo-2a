package a03a.sol2;

import java.util.List;

public interface Logics {
	
	List<String> allLines();
	
	void disable(int index);
	
	void closeAndWrite();
}
