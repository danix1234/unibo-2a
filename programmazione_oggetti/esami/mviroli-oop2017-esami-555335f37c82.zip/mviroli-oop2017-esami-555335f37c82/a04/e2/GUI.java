package a04.e2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.util.List;


public class GUI extends JFrame{
	
}

