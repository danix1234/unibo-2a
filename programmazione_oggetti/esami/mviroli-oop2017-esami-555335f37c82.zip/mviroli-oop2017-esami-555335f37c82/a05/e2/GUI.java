package a05.e2;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;



public class GUI extends JFrame{
	
	public GUI(int size){
	}
	
	public static void main(String[] args) {
		new GUI(6);
	}

}

