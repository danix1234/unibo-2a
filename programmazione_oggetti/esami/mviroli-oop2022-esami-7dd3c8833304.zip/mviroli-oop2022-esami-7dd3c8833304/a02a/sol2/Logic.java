package a02a.sol2;

public interface Logic {
    
    void hit(int x, int y);

    boolean isAvailable(int x, int y);

    boolean isBishop(int x, int y);

}
