package a01b.sol2;

public interface Logic {
    
    void hit(int x, int y);

    boolean isEnabled(int x, int y);

    boolean isOver();
}
