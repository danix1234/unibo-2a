package a01a.sol2;

public interface Logic {
    
    boolean toggle(int x, int y);

    boolean isOver();
}
