package a05a.sol2;

public interface Logics{
	
	void select(int x, int y);
	
	boolean isOver();
	
	boolean hasElement(int x, int y);
    
}
