package a05b.sol2;

public interface Logics{
	
	void tick();
	
	boolean isOver();
	
	boolean hasElement(int x, int y);
    
}
