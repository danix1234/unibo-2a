package a01b.sol2;

import java.util.Optional;

public interface Logics{
	
    Optional<Integer> hit(int x, int y);
    
    boolean won();
}
