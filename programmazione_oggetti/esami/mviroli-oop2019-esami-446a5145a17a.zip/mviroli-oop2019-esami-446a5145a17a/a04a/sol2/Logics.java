package a04a.sol2;

public interface Logics{
	
	void tick();
	
	boolean isOver();
	
	Pair<Integer,Integer> getPosition();
    
}
