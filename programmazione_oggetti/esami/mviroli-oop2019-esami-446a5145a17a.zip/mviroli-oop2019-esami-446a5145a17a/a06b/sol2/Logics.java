package a06b.sol2;

import java.util.Optional;

public interface Logics{
	
	Optional<Pair<Integer,Integer>> next();
    
}
