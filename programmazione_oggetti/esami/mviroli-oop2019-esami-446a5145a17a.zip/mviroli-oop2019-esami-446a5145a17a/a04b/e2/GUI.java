package a04b.e2;

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class GUI extends JFrame {
    
    
    public GUI(int size) {
        this.setVisible(true);
    }
    
}
