package a02a.sol2;

import java.util.Set;

public interface Logics{
	
	void tick();
	
	Set<Pair<Integer,Integer>> getPositions();
    
}
