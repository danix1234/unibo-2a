package a03a.sol2;

public interface Logics{
    
    void hit(int row, int col);
        
    int getMark(int x, int y);
    
    boolean isDone();
   
}
