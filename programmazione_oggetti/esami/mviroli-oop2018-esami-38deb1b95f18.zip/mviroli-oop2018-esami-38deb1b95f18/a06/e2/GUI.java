package a06.e2;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.stream.*;
import javax.swing.*;
import java.util.List;


public class GUI extends JFrame{
	
	public GUI(int size){
	}
	
}
