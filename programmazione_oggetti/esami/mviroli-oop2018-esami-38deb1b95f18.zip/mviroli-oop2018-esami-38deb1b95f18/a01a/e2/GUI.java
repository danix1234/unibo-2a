package a01a.e2;

import javax.swing.*;

public class GUI extends JFrame {
    
    
    public GUI() {
      }
    
    
}
