package a03b.sol2;

import java.util.*;

public interface Logics{
    
    List<Integer> getNumbers();
    
    void toLeft(int pos);
    
    void toRight(int pos);
    
    boolean isDone();
}
