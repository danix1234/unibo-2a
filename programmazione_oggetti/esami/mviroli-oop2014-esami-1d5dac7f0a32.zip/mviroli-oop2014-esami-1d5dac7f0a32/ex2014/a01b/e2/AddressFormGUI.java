package ex2014.a01b.e2;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class AddressFormGUI extends JFrame{

	
	public AddressFormGUI(){}
}
