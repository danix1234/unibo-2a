package ex2014.a03.e2;


public class SelectorModelImpl implements SelectorModel {
		
}
