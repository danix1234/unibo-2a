package ex2014.a01.e2;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.util.stream.*;


public class FibonacciFormGUI extends JFrame{

	public FibonacciFormGUI(int size){
	}
}
