package ex2014.a05.sol1;

public enum Answer {

	/**
	 * Possible answers to a guess.
	 */
	TOO_HIGH, TOO_LOW, CORRECT
	
}
