package ex2014.a03b.e2;

public class CodeModelImpl implements CodeModel {
	
	
}
