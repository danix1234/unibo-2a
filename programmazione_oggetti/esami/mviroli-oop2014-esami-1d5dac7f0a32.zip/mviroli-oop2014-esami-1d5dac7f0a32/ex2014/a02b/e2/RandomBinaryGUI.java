package ex2014.a02b.e2;

import java.awt.*;
import java.util.*;
import javax.swing.*;


public class RandomBinaryGUI extends JFrame{
	
	public RandomBinaryGUI(String fileName){
		
		// Inizializzazione base
		this.setSize(500, 100);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new FlowLayout());
		
				this.setVisible(true);
	}

}
