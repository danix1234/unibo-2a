# Lambdas/streams

## Instructions

Complete `LambdaFilter`. Verify the correctness of your solution by running the GUI application, or write a JUnit test class for the purpose.