# Lambdas

## Instructions

Complete `LambdaUtilities` by using lambdas to implement useful operations on collections (lists, maps). 
Verify the correctness of your solution through the provided test class, `TestLambdaUtilities`.