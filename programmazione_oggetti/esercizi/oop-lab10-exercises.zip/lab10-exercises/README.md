# How to use this repository

Recommended strategy:
* Create your own copy of this repository on your profile
* Clone this repository locally
* Remove the `origin` remote
* Create a new `origin` remote pointing to your copy
* Push the exercises branch on your copy, setting the branch upstream contextually (use `git push -u origin exercises`)
* Commit progressively when resolving the exercise and push changes on your repo
