# Lambdas/streams

## Instructions

Read the `MusicGroup` interface, and provide an implementation in `MusicGroupImpl`.
Notice that all the methods can be implemented through a *single expression*, by composing operations on streams.
Verify the correctness of your solution through the provided test class, `TestMusicGroup`.