package it.unibo.composition;

public interface User {
    String getUsername();

    String getPassword();

    String getDescription();
}
