plugins {
    application
    java
}

application {
    mainClass.set("it.unibo.mvc.LaunchApp")
}

tasks.javadoc {
    isFailOnError = false
}

tasks.javadoc {
    isFailOnError = false
}
