package it.unibo.mvc;


/**
 * Application controller. Performs the I/O.
 */
public class Controller {

}
