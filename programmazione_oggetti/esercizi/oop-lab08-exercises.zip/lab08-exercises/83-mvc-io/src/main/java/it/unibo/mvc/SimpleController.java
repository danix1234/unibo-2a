package it.unibo.mvc;

/**
 * 
 *
 */
public final class SimpleController implements Controller {

}
