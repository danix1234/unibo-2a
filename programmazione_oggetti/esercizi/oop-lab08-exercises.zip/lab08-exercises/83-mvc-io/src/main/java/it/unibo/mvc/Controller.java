package it.unibo.mvc;

/**
 *
 */
public interface Controller {

}
