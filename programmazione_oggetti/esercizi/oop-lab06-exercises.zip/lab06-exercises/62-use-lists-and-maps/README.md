# Use lists, maps, and measure their performance

1. Observe, compile, and execute `TestPerformance`. It estimates the time required to run an operation in Java.
2. Follow the instructions in `UseListsAndMaps`.
