# INSTRUCTIONS

1. Implement interface Graph
2. Complete the test UseGraph
3. Run the test and understand the outcome

**Bonus**: implement a Graph where the exploration strategy can be selected arbitrarily.
Implement both a depth-first strategy and a breadth-first strategy.
Helpful readings:
* http://artint.info/html/ArtInt_51.html
* https://en.wikipedia.org/wiki/Strategy_pattern
