class TestStudent {

    public static void main(String[] args) {
        Student someone = new Student();
        someone.build();
        someone.printStudentInfo();
    }
}
