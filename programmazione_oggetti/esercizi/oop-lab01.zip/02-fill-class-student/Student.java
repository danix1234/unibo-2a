class Student {

    // È buona pratica mettere i campi in testa alla classe

    void build(/* Qui vanno i parametri necessari a inizializzare l'oggetto */) {
        /*
         * Completare il corpo del metodo
         */
    }

    void printStudentInfo() {
        /*
         * Completare il corpo del metodo
         */
    }
}
