/*
 * Esempio di prima applicazione
 */
class HelloWorld {
    /*
     * Main dell'applicazione
     */
    public static void main(String[] argv) {
        /*
         * Stampa "Hello World!" in standard output
         */
        System.out.println("Hello, world!");
    }
}
