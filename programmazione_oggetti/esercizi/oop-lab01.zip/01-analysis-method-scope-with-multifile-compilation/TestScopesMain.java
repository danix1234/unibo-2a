class TestScopesMain {
    public static void main(String[] argv) {
        Scopes testObj = new Scopes();
        testObj.build(1, 2);
        testObj.dummyMethod(3);
        testObj.dummyMethod2(4);
    }
}
