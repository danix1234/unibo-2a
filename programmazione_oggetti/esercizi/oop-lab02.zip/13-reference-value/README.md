# Passaggio degli argomenti per valore o riferimento

1. Si preveda l'output di `CallByValue`, `CallByReference1` e `CallByReference2`
2. Si scriva su un foglio l'output previsto
3. Si compili e si esegua per verificare la previsione
4. Se la previsione non è corretta, chiedere al docente una spiegazione
