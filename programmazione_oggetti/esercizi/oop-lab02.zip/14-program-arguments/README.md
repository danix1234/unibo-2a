# Gestione degli argomenti passati da linea di comando

1. Si seguano le istruzioni fornite nel commento del file sorgente fornito
